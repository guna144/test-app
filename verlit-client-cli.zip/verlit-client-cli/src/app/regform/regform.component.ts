import { Component, OnInit } from '@angular/core';
import { Register } from '../_models/register';
import { RegService } from '../_services/register.service';
import { Observable } from 'rxjs/Rx';
import { Http, Response, Headers, RequestOptions } from '@angular/http';

@Component({
  selector: 'app-regform',
  templateUrl: './regform.component.html',
  styleUrls: ['./regform.component.css']
})
export class RegformComponent implements OnInit {

  // model = new Register('','','','','','','',new Date,'','','','','','','','',0,0,'','','','','','','','',0,'','','');
  model = new Register('43534','jkhkjhjk','mhgjhgjh','gunadsfds','male','jkgkgk','sdfsd',new Date,'2343242424','2343242424','gunadsfds','gunadsfds','gunadsfds','gunadsfds','gunadsfds','gunadsfds',4354343,43543535,'gunadsfds','gunadsfds','gunadsfds','gunadsfds','gunadsfds','gunadsfds','gunadsfds','gunadsfds',36,'gunadsfds','gunadsfds','gunadsfds');
  

  constructor(private _regService : RegService, private http : Http) { }

  ngOnInit() {
  }

  // Local properties
    register: Register[];

  getUser(){

     // Get all comments
         this._regService.getUsers()
                           .subscribe(
                               register => this.register = register, //Bind to view
                                err => {
                                    // Log errors if any
                                    console.log(err);
                                });


     
    console.log("get user "+this.register);
  }
  saveUserRegDetails(){
    console.log("saveUserRegDetails : "+this.model);
    
    // Variable to hold a reference of addComment/updateComment
        let commentOperation:Observable<RegService[]>;
        // commentOperation =
    // Create a new comment
      this._regService.registerUser(this.model)
      console.log(`saved!!! ${JSON.stringify(this.model)}`);
  }

  get currentRegister(){
    return JSON.stringify(this.model);
  }

}
