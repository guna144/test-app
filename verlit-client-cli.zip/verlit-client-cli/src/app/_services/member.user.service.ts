import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';

import { MemberUser } from '../_models/member.user';

@Injectable()
export class MemberUserService {
    constructor(private http: Http) { }

    getAll() {
        return this.http.get('/memberuser').map((response: Response) => response.json());
    }

    getById(_id: string) {
        return this.http.get('/memberuser/' + _id).map((response: Response) => response.json());
    }

    create(user: MemberUser) {
        // return this.http.post('/memberuser/sendmail', user);
        return this.http.post('/memberuser/adduser', user);
    }

    update(user: MemberUser) {
        return this.http.put('/memberuser/' + user._id, user);
    }

    delete(_id: string) {
        return this.http.delete('/memberuser/' + _id);
    }
}