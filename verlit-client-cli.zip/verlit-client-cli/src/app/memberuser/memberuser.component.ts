import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../_models/index';
import { AlertService, MemberUserService } from '../_services/index';

@Component({
  selector: 'app-memberuser',
  templateUrl: './memberuser.component.html',
  styleUrls: ['./memberuser.component.css']
})
export class MemberUserComponent implements OnInit {

  model: any = {};
  currentUser: User;
  constructor(
        private router: Router,
        private memberUserService: MemberUserService,
        private alertService: AlertService) { 
          this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        }

  ngOnInit() {
  }

    addUser(){

    this.model.sponsorId = "123"; 
    this.model.sponsorName = this.currentUser.username;
    this.model.orgSponsorId = "456";
    this.model.orgSponsorName = "test456";
    this.model.password = "ver"+this.model.username;

      this.memberUserService.create(this.model)
      .subscribe(
          data => {
              this.alertService.success('Registration successful', true);
              this.router.navigate(['/tree']);
          },
          error => {
              this.alertService.error(error);
              // this.loading = false;
          });
  }

}
