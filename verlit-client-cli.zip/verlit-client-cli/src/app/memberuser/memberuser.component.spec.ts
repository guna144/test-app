import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MemberUserComponent } from './memberuser.component';

describe('MemberUserComponent', () => {
  let component: MemberUserComponent;
  let fixture: ComponentFixture<MemberUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MemberUserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MemberUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
