export class Register{
    constructor(
        public sponsorId: string,
        public sponsorName : string,
        public position: string, // (Org1 / Org2)
        public name: string,
        public gender: string,
        public fatherName: string,
        public motherName: string,
        public doB: Date,
        public mobile: string,
        public alternate_Mobile: string,
        public emailId: string,
        public occupation: string,
        public maritalStatus: string,
        public address: string,
        public city: string,
        public state: string,
        public pin: number,
        public bankACNumber: number,
        public acHolderName: string,
        public acType: string,
        public bankName: string,
        public branchName: string,
        public branchLocation: string,
        public iFSC: string, 
        public pan: string,
        public nomineeName: string,
        public age: number,
        public relation: string,
        public nomineeAddress: string,
        public modeOfDelivery: string // (speed post/ courier)
    ){}
}