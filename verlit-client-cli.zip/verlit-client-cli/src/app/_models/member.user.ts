export class MemberUser {
    _id: string;
    sponsorId: string;
	sponsorName : string;
	orgSponsorId: string;
	orgSponsorName : string;
    username: string;
    emailId: string;
    mobileNo: string;
    userType: string;
    position: string;
    password: string;
}