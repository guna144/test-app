"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.appConfig = {
    apiUrl: 'http://localhost:4000'
};
//# sourceMappingURL=app.config.js.map