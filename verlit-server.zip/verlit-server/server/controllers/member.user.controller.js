var config = require('config.json');
var express = require('express');
var router = express.Router();
var memberUserService = require('services/member.user.service');
var email   = require("emailjs/email");

// routes
// router.post('/authenticate', authenticate);
router.post('/adduser', register);
router.get('/', getAll);
router.get('/current', getCurrent);
router.put('/:_id', update);
router.delete('/:_id', _delete);
router.post('/sendmail',sendMail);

module.exports = router;

function authenticate(req, res) {
    userService.authenticate(req.body.username, req.body.password)
        .then(function (user) {
            if (user) {
                // authentication successful
                res.send(user);
            } else {
                // authentication failed
                res.status(400).send('Username or password is incorrect');
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function register(req, res) {
    console.log("register create ok ");
    memberUserService.create(req.body)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getAll(req, res) {
    memberUserService.getAll()
        .then(function (users) {
            res.send(users);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getCurrent(req, res) {
    memberUserService.getById(req.user.sub)
        .then(function (user) {
            if (user) {
                res.send(user);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function update(req, res) {
    memberUserService.update(req.params._id, req.body)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function _delete(req, res) {
    memberUserService.delete(req.params._id)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
function sendMail(req, res){
console.log("sendMail test ok ");
    console.log("req : "+req.body);
    var server  = email.server.connect({
       user:    "admin@myverlit.com", 
       password:"admin@123", 
       host:    "mail.myverlit.com", 
       ssl:     true,
       Port: 465
    });

    // send the message and get a callback with an error or details of the message that was sent
    server.send({
       text:    "i hope this works", 
       from:    "admin@myverlit.com", 
       to:      "gunaemail@gmail.com",
       subject: "Welcome testing emailjs"
    }, function(err, message) { 
        if(err)
            console.log(err );
        else
            return res.json({success : true, msg : 'sent'});
    });

    // var message = {
    //    text:    "i hope this works", 
    //    from:    "admin@myverlit.com", 
    //    to:      "gunaemail@gmail.com",
    //    subject: "Welcome testing emailjs",
    //    attachment: 
    //    [
    //       {data:"<html>i <i>hope</i> this works!</html>", alternative:true},
    //       {path:"path/to/file.zip", type:"application/zip", name:"renamed.zip"}
    //    ]
    // };
}